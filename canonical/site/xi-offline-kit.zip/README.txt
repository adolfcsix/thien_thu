Xi Universe — Local offline kit
Extract all files. Requires Python 3 installed. Run from extracted folder:
python -m http.server 8765 --bind 127.0.0.1 --directory site
Open http://localhost:8765/ in Chrome/Edge/Safari. Keep this address/port for saves. In Settings choose Download all games, import exported save JSON. Keep server running locally. No GitHub/network required. Not an iOS native install. Do not delete original PWA or its data.
