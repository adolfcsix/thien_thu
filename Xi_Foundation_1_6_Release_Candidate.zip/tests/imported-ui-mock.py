"""DOM smoke, mocked storage and navigation; no real origin or offline claim."""
from pathlib import Path
import os,json
from playwright.sync_api import sync_playwright
site=Path(__file__).resolve().parents[1]/'site'
with sync_playwright() as p:
 opts={'args':['--no-sandbox','--disable-dev-shm-usage']}
 if os.environ.get('CHROMIUM_PATH'):opts['executable_path']=os.environ['CHROMIUM_PATH']
 b=p.chromium.launch(**opts)
 pg=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,reduced_motion='reduce');errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
 def open_game(id,values):
  html=(site/f'games/{id}/index.html').read_text(); mock='<script>window.xiStore='+json.dumps(values)+';Object.defineProperty(window,"localStorage",{configurable:true,value:{getItem(k){return xiStore[k]??null},setItem(k,v){xiStore[k]=String(v)}}});window.xiReturned=false;</script>'
  html=html.replace('<script>',mock+'<script>',1).replace("location.assign('../../')","window.xiReturned=true")
  pg.set_content(html)
 open_game('cubiq',{});pg.locator('canvas').wait_for();pg.locator('[data-act="menu"]').click();pg.locator('[data-act="sound"]').click();pg.get_by_role('button',name='Về sảnh Xi').click();assert pg.evaluate('xiReturned');saved=pg.evaluate('xiStore');assert 'xi:game:cubiq:save' in saved;assert pg.evaluate('document.documentElement.scrollWidth<=innerWidth')
 open_game('block-nova',saved);pg.locator('#board').wait_for();pg.locator('#home').click();pg.get_by_role('button',name='Adventure').click();pg.locator('#home').click();pg.get_by_role('button',name='Thử thách tuần').click();pg.locator('#home').click();pg.get_by_role('button',name='Về sảnh Xi').click();assert pg.evaluate('xiReturned');assert pg.evaluate("['classic','adventure','weekly','best','sound'].every(k=>xiStore['xi:game:block-nova:'+k]!==undefined)");assert pg.evaluate("xiStore['xi:game:cubiq:save']")==saved['xi:game:cubiq:save'];assert pg.evaluate('document.documentElement.scrollWidth<=innerWidth');assert not errors,errors
 print('PASS CUBIQ menu/save/hub and BLOCK NOVA three modes/save/hub, isolated mock storage');b.close()
