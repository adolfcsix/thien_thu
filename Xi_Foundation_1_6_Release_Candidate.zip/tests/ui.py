from pathlib import Path
from base64 import b64encode
import os
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]/'site'
def data(p,m):return 'data:'+m+';base64,'+b64encode((root/p).read_bytes()).decode()
html=(root/'index.html').read_text().replace('<link rel="stylesheet" href="hub.css">','<style>'+(root/'hub.css').read_text()+'</style>').replace('src="assets/icon-192.png"','src="'+data('assets/icon-192.png','image/png')+'"')
# Mock browser messaging only: no real offline/Service Worker claim in UI test.
mock="""let ready=true;const worker={postMessage(msg,ports){if(msg.type==='REMOVE')ready=false;if(msg.type==='INSTALL')ready=true;ports[0].postMessage({ok:true,value:msg.type==='DETAILS'?{legacy:{ready,installedVersion:ready?'9.0':null,availableVersion:'9.0',bytes:ready?1048576:0,activeBytes:ready?1048576:0,backupBytes:0,needsRepair:false,updateAvailable:false}}:true})}};Object.defineProperty(navigator,'serviceWorker',{value:{getRegistration:async()=>({active:worker}),register:async()=>({active:worker}),ready:Promise.resolve(),addEventListener(){}}});"""
cat=(root/'catalog-data.js').read_text()
for name in ['legacy','cubiq','block-nova']:
 p=f'assets/{name}-cover.webp';cat=cat.replace(p,data(p,'image/webp'))
js=(root/'hub.js').read_text().replace("import {games,released,HUB_VERSION,getGame} from './catalog.js';","const {games,released,HUB_VERSION,getGame}=globalThis.XI_CATALOG;")
html=html.replace('<script type="module" src="hub.js"></script>','<script>'+mock+cat+js+'</script>')
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH') or None,args=['--no-sandbox','--disable-dev-shm-usage']);
 for w,h in [(320,720),(390,844),(844,390),(1280,800)]:
  page=b.new_page(viewport={'width':w,'height':h},is_mobile=w<1000,has_touch=w<1000);errs=[];page.on('pageerror',lambda e:errs.append(str(e)));page.set_content(html);page.get_by_role('button',name='Bỏ qua').click();assert page.locator('#intro').is_hidden();assert not page.locator('#shell').evaluate('(el)=>el.inert');page.get_by_text('Sẵn sàng offline',exact=False).first.wait_for();assert page.evaluate('document.documentElement.scrollWidth <= innerWidth');assert page.get_by_text('CHƯA PHÁT HÀNH',exact=True).count()==2;assert page.locator('#featured article').count()==3
  if w==390:page.screenshot(path=str(root.parent/'hub-preview.png'),full_page=True)
  if w==1280:page.screenshot(path=str(root.parent/'hub-desktop.png'),full_page=True)
  page.get_by_role('button',name='Thư viện').click();assert page.locator('#resourceTotal').inner_text()=='1.00 MiB';
  if w==390:page.screenshot(path=str(root.parent/'library-preview.png'),full_page=True)
  page.on('dialog',lambda d:d.accept());page.get_by_role('button',name='Gỡ tài nguyên').click();page.get_by_text('Đã gỡ tài nguyên. Tiến trình vẫn còn.').wait_for();page.get_by_role('button',name='Tải offline').first.click();page.get_by_text('Đã lưu đủ tài nguyên offline.').wait_for();page.get_by_role('button',name='Cài đặt',exact=True).click();assert page.get_by_text('Tiến trình & bộ nhớ').is_visible();assert page.locator('#introEnabled').is_checked();page.locator('#introEnabled').uncheck();assert not page.locator('#introEnabled').is_checked();assert not errs,errs;page.close();print(f'PASS {w}x{h}: layout, tabs, mocked cache actions')
 page=b.new_page(viewport={'width':390,'height':844},reduced_motion='reduce');page.set_content(html);assert page.locator('#intro').is_hidden();assert not page.locator('#shell').evaluate('(el)=>el.inert');page.close();print('PASS reduced motion skips intro')
 page=b.new_page(viewport={'width':390,'height':844});page.set_content(html);assert page.get_by_role('button',name='Bỏ qua').is_visible();page.locator('#intro').wait_for(state='hidden',timeout=4500);assert not page.locator('#shell').evaluate('(el)=>el.inert');page.close();print('PASS intro auto-dismiss')
 # Additional presentation checks with synthetic older/incomplete installations.
 for state,label in [('update','Cập nhật'),('repair','Khôi phục')]:
  sample="{ready:true,installedVersion:'8.9',availableVersion:'9.0',bytes:2097152,activeBytes:1048576,backupBytes:1048576,needsRepair:false,updateAvailable:true}" if state=='update' else "{ready:false,installedVersion:null,availableVersion:'9.0',bytes:0,activeBytes:0,backupBytes:0,needsRepair:true,updateAvailable:false}"
  special=html.replace("{ready,installedVersion:ready?'9.0':null,availableVersion:'9.0',bytes:ready?1048576:0,activeBytes:ready?1048576:0,backupBytes:0,needsRepair:false,updateAvailable:false}",sample)
  page=b.new_page(viewport={'width':390,'height':844},reduced_motion='reduce');page.set_content(special);page.get_by_role('button',name='Thư viện').click();page.get_by_role('button',name=label,exact=True).wait_for();assert page.get_by_role('button',name=label,exact=True).is_enabled();page.close();print('PASS simulated '+state+' presentation')
 # Stale cache state: revalidate immediately before launching even without a focus event.
 page=b.new_page(viewport={'width':390,'height':844},reduced_motion='reduce');page.set_content(html);page.get_by_text('Sẵn sàng offline',exact=False).first.wait_for()
 page.evaluate("ready=false;Object.defineProperty(navigator,'onLine',{value:false,configurable:true})")
 page.get_by_role('button',name='Chơi ngay').first.click();page.get_by_text('Trò chơi chưa đủ tài nguyên. Kết nối Internet để chuẩn bị.').wait_for();assert page.get_by_role('button',name='Chơi ngay').first.is_disabled();assert page.locator('#discover h2').is_visible()
 page.evaluate("ready=true;window.dispatchEvent(new Event('focus'))");page.get_by_text('Sẵn sàng offline',exact=False).first.wait_for();assert page.get_by_role('button',name='Chơi ngay').first.is_enabled();page.close();print('PASS stale status revalidated on launch and focus')
 b.close()
