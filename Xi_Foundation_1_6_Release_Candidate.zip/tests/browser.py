"""Real SW acceptance. Use the original V9 archive and the exact candidate site.
No network mocks or forced activation. Run on a normal local/CI browser.
"""
from pathlib import Path
import argparse, functools, http.server, json, os, shutil, tempfile, threading, zipfile
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--engine', choices=['chromium', 'webkit'], default='chromium')
parser.add_argument('--site', type=Path, default=ROOT/'site')
parser.add_argument('--baseline', type=Path, default=ROOT/'fixtures'/'V9.0.zip')
args = parser.parse_args()
KEY = 'thien-thu-v8'
RECOVERY = KEY+'-recovery'

class Handler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *args): pass
    def end_headers(self):
        self.send_header('Cache-Control', 'no-store')
        super().end_headers()

def storage(page):
    return page.evaluate('(keys)=>keys.map(k=>localStorage.getItem(k))', [KEY, RECOVERY])

def rpc(page, kind, game_id="legacy"):
    return page.evaluate('''async ([type,id])=>{const r=await navigator.serviceWorker.ready;const ch=new MessageChannel();return new Promise((resolve,reject)=>{const t=setTimeout(()=>reject(Error('worker timeout')),30000);ch.port1.onmessage=e=>{clearTimeout(t);ch.port1.close();resolve(e.data)};(navigator.serviceWorker.controller||r.active).postMessage({type,id},[ch.port2])})}''', [kind,game_id])

with tempfile.TemporaryDirectory() as tmp:
    root = Path(tmp)
    target = root/'thien_thu'; target.mkdir()
    with zipfile.ZipFile(args.baseline) as z: z.extractall(target)
    server = http.server.ThreadingHTTPServer(('127.0.0.1',0), functools.partial(Handler,directory=str(root)))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    url = f'http://127.0.0.1:{server.server_port}/thien_thu/'
    try:
        with sync_playwright() as p:
            opts = {}
            if args.engine == 'chromium' and os.environ.get('CHROMIUM_PATH'):
                opts['executable_path'] = os.environ['CHROMIUM_PATH']
            browser = getattr(p,args.engine).launch(**opts)
            ctx = browser.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,reduced_motion='reduce',accept_downloads=True)
            ctx.set_default_timeout(20000)
            errors = []
            ctx.on('page', lambda pg:pg.on('pageerror',lambda e:errors.append(str(e))))
            page = ctx.new_page(); page.goto(url)
            page.wait_for_function('!!navigator.serviceWorker.controller',timeout=30000)
            page.locator('#brandIntro').wait_for(state='hidden')
            page.locator('#newBtn').click(); page.locator('[data-map="0"]').click(); page.locator('#start').click(); page.locator('#homeBtn').click()
            page.evaluate('(k)=>localStorage.setItem(k,"recovery fixture")',RECOVERY)
            before = storage(page); assert json.loads(before[0])['game']['wave']==1
            # Atomic directory switch, preserving the URL and original profile.
            shutil.rmtree(target); shutil.copytree(args.site,target)
            page.evaluate('async()=>{const r=await navigator.serviceWorker.getRegistration();await r.update()}')
            page.wait_for_function('async()=>!!(await navigator.serviceWorker.getRegistration()).waiting',timeout=30000)
            assert storage(page)==before
            page.close()
            page=ctx.new_page();page.goto(url)
            # Activation is asynchronous. Reload only after the new worker is active.
            page.wait_for_function('async()=>{const r=await navigator.serviceWorker.getRegistration();return !!r?.active&&!r.waiting&&!r.installing}',timeout=30000)
            page.reload();page.locator('#discover h2').wait_for();page.get_by_text('Sẵn sàng offline',exact=False).first.wait_for(timeout=30000)
            assert storage(page)==before
            assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
            assert not page.evaluate('async()=> (await caches.keys()).some(k=>k.startsWith("thien-thu:"))')
            print('PASS same-origin V9 migration, both save keys, layout',flush=True)
            ctx.set_offline(True);page.reload();page.get_by_role('button',name='Chơi ngay').first.click();page.locator('#brandIntro').wait_for(state='hidden');page.locator('#continueBtn').click();page.locator('#chapter').wait_for();page.locator('#hubBtn').click();page.locator('#discover h2').wait_for()
            print('PASS offline launch/resume and return to hub',flush=True)
            # A second live game window must block destructive operations.
            other=ctx.new_page();other.goto(url+'games/legacy/index.html');other.locator('#brandIntro').wait_for(state='hidden')
            result=rpc(page,'REMOVE');assert not result['ok'],result
            other.close();page.bring_to_front();page.get_by_role('button',name='Thư viện').click();page.on('dialog',lambda d:d.accept());saved=storage(page)
            page.get_by_role('button',name='Gỡ tài nguyên').click();page.get_by_text('Đã gỡ tài nguyên. Tiến trình vẫn còn.').wait_for();assert page.get_by_role('button',name='Chơi ngay').first.is_disabled();assert storage(page)==saved
            assert not page.evaluate('async()=> (await caches.keys()).some(k=>k.includes(":game:legacy:"))')
            assert not rpc(page,'INSTALL')['ok'];assert storage(page)==saved
            print('PASS multi-window protection, offline removal, failed download preserves save',flush=True)
            ctx.set_offline(False);page.get_by_role('button',name='Tải offline').first.click();page.get_by_text('Đã lưu đủ tài nguyên offline.').wait_for();assert storage(page)==saved
            # Simulate eviction of one real cached resource, then repair.
            page.evaluate('''async()=>{for(const k of await caches.keys()){if(k.includes(':game:legacy:')){const c=await caches.open(k);await c.delete(new URL('games/legacy/src/render.js',location.href).href)}}}''')
            page.get_by_role('button',name='Cài đặt',exact=True).click();page.locator('#refresh').click();page.get_by_role('button',name='Thư viện').click();page.get_by_role('button',name='Khôi phục',exact=True).click();page.get_by_text('Đã lưu đủ tài nguyên offline.').wait_for();assert storage(page)==saved
            ctx.set_offline(True);page.get_by_role('button',name='Chơi ngay').first.click();page.locator('#brandIntro').wait_for(state='hidden');page.locator('#settingsHome').click()
            with page.expect_download() as download: page.locator('#exportBtn').click()
            backup=root/'backup.json';download.value.save_as(backup)
            assert json.loads(backup.read_text())['game']['wave']==1
            page.locator('#importFile').set_input_files(str(backup));page.locator('#settings').wait_for(state='hidden');assert page.locator('#continueBtn').is_enabled();page.locator('#continueBtn').click();page.locator('#chapter').wait_for();page.locator('#hubBtn').click();page.locator('#discover h2').wait_for()
            assert not errors,errors
            print('PASS cache eviction repair, offline backup export/import, no uncaught JS errors',flush=True)
            # New modules: independently download, run offline, persist, remove and restore.
            ctx.set_offline(False)
            for game in ('cubiq','block-nova'):
                assert rpc(page,'INSTALL',game)['ok']
            ctx.set_offline(True)
            page.goto(url+'games/cubiq/index.html');page.locator('canvas').wait_for();page.locator('[data-act="menu"]').click();page.locator('[data-act="sound"]').click();page.get_by_role('button',name='Về sảnh Xi').click();page.locator('#discover h2').wait_for()
            cubiq=page.evaluate("localStorage.getItem('xi:game:cubiq:save')");assert cubiq
            page.goto(url+'games/block-nova/index.html');page.locator('#board').wait_for();page.locator('#home').click();page.get_by_role('button',name='Adventure').click();page.locator('#home').click();page.get_by_role('button',name='Thử thách tuần').click();page.locator('#home').click();page.get_by_role('button',name='Về sảnh Xi').click();page.locator('#discover h2').wait_for()
            keys=['xi:game:block-nova:'+k for k in ['classic','adventure','weekly','best','sound']]
            nova=page.evaluate('(keys)=>keys.map(k=>localStorage.getItem(k))',keys);assert all(x is not None for x in nova)
            assert rpc(page,'REMOVE','cubiq')['ok'];d=rpc(page,'DETAILS')['value'];assert not d['cubiq']['ready'] and d['block-nova']['ready'] and d['legacy']['ready'];assert page.evaluate("localStorage.getItem('xi:game:cubiq:save')")==cubiq
            ctx.set_offline(False);assert rpc(page,'INSTALL','cubiq')['ok'];ctx.set_offline(True);page.goto(url+'games/cubiq/index.html');page.locator('canvas').wait_for();page.locator('[data-act="menu"]').click();page.get_by_role('button',name='Về sảnh Xi').click();page.locator('#discover h2').wait_for()
            assert page.evaluate('(keys)=>keys.map(k=>localStorage.getItem(k))',keys)==nova
            assert not errors,errors
            print('PASS three independent offline games, remove/reinstall and saves',flush=True)
            browser.close()
    finally:
        server.shutdown();server.server_close()
