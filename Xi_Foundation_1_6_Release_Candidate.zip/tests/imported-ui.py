"""Game UI + storage adapter smoke on routed HTTP origin; not actual SW acceptance."""
from pathlib import Path
import os,json
from playwright.sync_api import sync_playwright
site=Path(__file__).resolve().parents[1]/'site'
with sync_playwright() as p:
 opts={'args':['--no-sandbox','--disable-dev-shm-usage']}
 if os.environ.get('CHROMIUM_PATH'):opts['executable_path']=os.environ['CHROMIUM_PATH']
 b=p.chromium.launch(**opts)
 ctx=b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,reduced_motion='reduce')
 # Serve original HTML from a route; no real Service Worker in this test.
 def route(r):
  path=r.request.url.split('/thien_thu/',1)[-1]
  if path in ['games/cubiq/index.html','games/block-nova/index.html']:
   r.fulfill(status=200,content_type='text/html',body=(site/path).read_text())
  else:r.fulfill(status=200,content_type='text/html',body='<h1>Hub fixture</h1>')
 ctx.route('https://xi-test.example/**',route)
 pg=ctx.new_page();errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
 base='https://xi-test.example/thien_thu/'
 pg.goto(base+'games/cubiq/index.html');pg.locator('canvas').wait_for();pg.locator('[data-act="menu"]').click();pg.locator('[data-act="sound"]').click();pg.get_by_role('button',name='Về sảnh Xi').click();pg.get_by_text('Hub fixture').wait_for();assert pg.evaluate("!!localStorage.getItem('xi:game:cubiq:save')");saved=pg.evaluate("localStorage.getItem('xi:game:cubiq:save')")
 pg.goto(base+'games/block-nova/index.html');pg.locator('#board').wait_for();pg.locator('#home').click();pg.get_by_role('button',name='Adventure').click();pg.locator('#home').click();pg.get_by_role('button',name='Thử thách tuần').click();pg.locator('#home').click();pg.get_by_role('button',name='Về sảnh Xi').click();pg.get_by_text('Hub fixture').wait_for();assert pg.evaluate("['classic','adventure','weekly','best','sound'].every(k=>localStorage.getItem('xi:game:block-nova:'+k)!==null)");assert pg.evaluate("localStorage.getItem('xi:game:cubiq:save')")==saved
 assert not errors,errors
 print('PASS CUBIQ menu/save/hub, BLOCK NOVA three modes/save/hub, independent saves')
 b.close()
