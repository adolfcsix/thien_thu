// Scope-specific cache: multiple installs on the same origin must not erase each other.
const PREFIX='thien-thu:'+self.registration.scope+':';
const CACHE=PREFIX+'v9.0';
const FILES=['./','./index.html','./style.css','./manifest.webmanifest','./src/app.js','./src/intro.js','./src/audio.js','./src/input.js','./src/performance.js','./src/data.js','./src/engine.js','./src/render.js','./src/save.js','./assets/icon-192.png','./assets/icon-512.png','./assets/icon-180.png','./assets/icon-maskable.png','./assets/brand-mark.png','./assets/brand-star.png'];
// Do not force a new worker onto a live old-version game.
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(FILES.map(path=>new Request(new URL(path,self.registration.scope),{cache:'reload'}))))));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith(PREFIX)&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{const req=event.request;if(req.method!=='GET'||new URL(req.url).origin!==self.location.origin||!req.url.startsWith(self.registration.scope))return;event.respondWith((async()=>{const cache=await caches.open(CACHE);return await cache.match(req.mode==='navigate'?'./index.html':req)||fetch(req)})())});
